﻿using GProd.Business.Diagrams.Kanbans;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Business.Commons
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {

        }

        public DbSet<KanbanBoard> KanbanBoards { get; set; }
        public DbSet<KanbanTask> KanbanTasks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<KanbanBoard>()
                .Property(f => f.Id)
                .ValueGeneratedOnAdd();

            modelBuilder.ApplyConfiguration(new KanbanBoardConfiguration());
        }
    }
}
