﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GProd.Business.Diagrams.Kanbans;
using System.Reflection.Emit;

namespace GProd.Business.Commons
{
    public class KanbanBoardConfiguration : IEntityTypeConfiguration<KanbanBoard>
    {
        public void Configure(EntityTypeBuilder<KanbanBoard> builder)
        {
            builder.HasData
            (
                new KanbanBoard
                {
                    Id = 1,
                    Label = "Board 01"
                }
            );
        }
    }
}
