﻿using GProd.Business.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Business.Diagrams.Kanbans
{
    public class KanbanTask : BusinessBase
    {
        public string Label { get; set; }
        public string Status { get; set; }
        public string Description { get; set; }

        public KanbanTask(string label, string status, string description)
        {
            Label = label;
            Status = status;
            Description = description;
        }
    }
}
