﻿using GProd.Business.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Business.Diagrams.Kanbans
{
    public class KanbanBoard : BusinessBase
    {
        public string Label { get; set; }
    }
}
