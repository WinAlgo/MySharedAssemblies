﻿using GProd.Client.Common;
using GProd.Shared.Dtos.Boards;
using System.Net.Http.Json;

namespace GProd.Client.HttpClients
{
    public interface IBoardServiceHttpClient
    {
        Task<IEnumerable<BoardAction>> Get();
    }

    public class BoardServiceHttpClient : HttpClientBase, IBoardServiceHttpClient
    {

        #region Attributes and Accessors

        #endregion

        #region Constructors
        public BoardServiceHttpClient(HttpClient httpClientService)
            : base(httpClientService)
        {

        }
        #endregion

        #region Methods
        public async Task<IEnumerable<BoardAction>> Get()
        {
            var result = await HttpClientService.GetFromJsonAsync<IEnumerable<BoardAction>>(Const.WebApiServiceName_BoardService);

            return result;
        }
        #endregion

    }
}
