﻿using GProd.Client.Common;
using GProd.Shared.Dtos.Boards;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using System.Text;
using GProd.Shared;
using System.Text.Json;
using GProd.Shared.Dtos;

namespace GProd.Client.HttpClients
{
    public interface ILogServiceHttpClient
    {
        Task LogInformation(string message);
    }

    public class LogServiceHttpClient : HttpClientBase, ILogServiceHttpClient
    {

        #region Attributes and Accessors

        #endregion

        #region Constructors
        public LogServiceHttpClient(HttpClient httpClientService)
            : base(httpClientService)
        {

        }
        #endregion

        #region Methods
        public async Task LogInformation(string msg)
        {
            LogDto obj = new (){ Message = msg };
            string jsonString = JsonSerializer.Serialize(obj);
            StringContent content = new(jsonString, Encoding.UTF8, "application/json");

            var response = await HttpClientService.PostAsync(Const.WebApiServiceName_Log, content);
        }
        #endregion

    }
}
