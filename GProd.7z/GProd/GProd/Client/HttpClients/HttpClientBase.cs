﻿namespace GProd.Client.HttpClients
{
    public class HttpClientBase

    {
        #region Attributes and Accessors
        protected HttpClient HttpClientService { get; }
        #endregion

        #region Constructors
        public HttpClientBase(HttpClient httpClientService)
        {
            HttpClientService = httpClientService;
        }
        #endregion

        #region Methods

        #endregion

    }
}
