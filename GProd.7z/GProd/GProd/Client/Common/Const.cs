﻿namespace GProd.Client.Common
{
    public class Const
    {
        // Web Api services
        internal const string WebApiServiceName_Log = "LogService";
        internal const string WebApiServiceName_BoardService = "BoardService";
    }
}
