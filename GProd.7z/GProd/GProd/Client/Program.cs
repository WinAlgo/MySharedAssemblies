using GProd.Client;
using GProd.Client.HttpClients;
using GProd.Shared;
using Grpc.Net.Client;
using Grpc.Net.Client.Web;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Syncfusion.Blazor;
using static GProd.Shared.ActionService;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

var services = builder.Services;

// Base address for services
services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

// Http client wrapper for Web Api services
services.AddScoped<IBoardServiceHttpClient, BoardServiceHttpClient>();
services.AddScoped<ILogServiceHttpClient, LogServiceHttpClient>();

// gRPC service
services.AddSingleton(services =>
{
    var httpClient = new HttpClient(new GrpcWebHandler(GrpcWebMode.GrpcWeb, new HttpClientHandler()));
    var baseUri = services.GetRequiredService<NavigationManager>().BaseUri;
    var channel = GrpcChannel.ForAddress(baseUri, new GrpcChannelOptions { HttpClient = httpClient });
    return new ActionServiceClient(channel);
});

// To use Syncfusion services
services.AddSyncfusionBlazor();

// Syncfusion licence key
Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Mgo+DSMBaFt9QHFqVkJrW05GckBAXWFKblV8RGtTf15gFChNYlxTR3ZZQFhjQH5bdkNkXnxZ;Mgo+DSMBPh8sVXJ2S0d+X1VPcUBAWXxLflF1VWVTflZ6dFVWACFaRnZdQV1lS3tTf0VrWXlZeXRS;ORg4AjUWIQA/Gnt2V1hhQlJAfVhdX2dWfFN0RnNfdV94flVGcDwsT3RfQF5jT3xWdkxjUX9YeHRTQQ==;MjUwNzU4MkAzMjMyMmUzMDJlMzBGRktZY0VHUHR0VGM0NXdFcUF2NVZKODY0a3FQSnB0UTVjOHRROUd0TURRPQ==;MjUwNzU4M0AzMjMyMmUzMDJlMzBlem1YVEY4bzhiOWlMRlFjcUNyQ1MzUEhRRmNmZUxRWjArTEFiaTF5blVvPQ==;NRAiBiAaIQQuGjN/V0R+XU9HclRFQmFNYVF2R2BJeVRxfF9GYEwxOX1dQl9gSXhRc0VqWXdednxTT2c=;MjUwNzU4NUAzMjMyMmUzMDJlMzBuaUFDODNFV01Bbk0raHg2b0dDSFlDUkNIWVV5eldIakNVeEg3RDhwM3BrPQ==;MjUwNzU4NkAzMjMyMmUzMDJlMzBYaWdDdkY3OHJ0Z0RMV0ZEdURQUER6NDhFYmFTcFQ1UjdhTGJVZDdHN0E0PQ==;Mgo+DSMBMAY9C3t2V1hhQlJAfVhdX2dWfFN0RnNfdV94flVGcDwsT3RfQF5jT3xWdkxjUX9YeXdTRw==;MjUwNzU4OEAzMjMyMmUzMDJlMzBRRXhiVG4wbi9FYzdrN1k5ZnRHbFlxR050NW43dVZ5YjBYRTlUc29UeHVjPQ==;MjUwNzU4OUAzMjMyMmUzMDJlMzBFdzlnTFR2RmxlWU9SYSszTFVvVmdGcTE4QnJrRmFiTG5iTTlESTg3eFZVPQ==;MjUwNzU5MEAzMjMyMmUzMDJlMzBuaUFDODNFV01Bbk0raHg2b0dDSFlDUkNIWVV5eldIakNVeEg3RDhwM3BrPQ==");

// Build and run the appplication
await builder.Build().RunAsync();
