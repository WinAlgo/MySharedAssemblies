﻿namespace GProd.Client.Pages
{
    public partial class Index : AppComponentBase
    {
    }
}
