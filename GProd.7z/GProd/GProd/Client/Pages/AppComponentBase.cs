﻿using GProd.Client.Common;
using GProd.Client.HttpClients;
using GProd.Shared.Dtos.Boards;
using Microsoft.AspNetCore.Components;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace GProd.Client.Pages
{
    /// <summary>
    /// Base class for Razor components
    /// </summary>
    public class AppComponentBase : ComponentBase
    {

        #region Attributes and Accessors
        [Inject]
        private ILogServiceHttpClient LogServiceHttpClient { get; set; }
        #endregion

        #region Constructors
        public AppComponentBase()
        {

        }
        #endregion

        #region Methods
        protected async Task LogInformation(string message)
        {
            await LogServiceHttpClient.LogInformation( message);
        }
        #endregion

    }
}
