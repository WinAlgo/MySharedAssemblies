﻿using GProd.Client.HttpClients;
using GProd.Shared.Dtos.Boards;
using Microsoft.AspNetCore.Components;
using System.Net.Http.Json;
using static System.Net.WebRequestMethods;

namespace GProd.Client.Pages
{
    //public partial class Board : AppComponentBase
    //{

    //    #region Attributes and Accessors
    //    [Inject]
    //    private IBoardServiceHttpClient BoardServiceHttpClient { get; set; }

    //    private BoardAction[] Tasks { get; set; }
    //    #endregion

    //    #region Constructors
    //    public Board()
    //    {

    //    }
    //    #endregion

    //    #region Methods
    //    protected override async Task OnInitializedAsync()
    //    {
    //        Tasks = await BoardServiceHttpClient.Get();
    //    }
    //    #endregion

    //}
}
