﻿using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Components;
using static GProd.Shared.ActionService;

namespace GProd.Client.Pages
{
    public partial class Board_gRPC : AppComponentBase
    {

        #region Attributes and Accessors
        [Inject]
        private ActionServiceClient client { get; set; }

        private IEnumerable<GProd.Shared.Action> Tasks { get; set; }
        #endregion

        #region Constructors

        #endregion

        #region Methods
        protected override async Task OnInitializedAsync()
        {
            Tasks = (await client.GetActionsAsync(new Empty())).Actions;
        }
        #endregion


    }
}
