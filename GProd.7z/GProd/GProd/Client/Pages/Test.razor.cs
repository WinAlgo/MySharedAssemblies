﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;

namespace GProd.Client.Pages
{
    public partial class Test : AppComponentBase
    {
        private async Task BtnLog_Click(MouseEventArgs mouseEventArgs)
        {
           await LogInformation("Test");
        }
    }
}
