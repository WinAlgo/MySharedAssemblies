﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Shared.Dtos.Boards
{
    public class BoardAction
    {

        public string Id { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string Summary { get; set; }

        public BoardAction(string id, string title, string status, string summary)
        {
            Id = id;
            Title = title;
            Status = status;
            Summary = summary;
        }
    }
}
