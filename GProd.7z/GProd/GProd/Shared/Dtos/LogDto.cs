﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Shared.Dtos
{
    public class LogDto
    {
        public string Message { get; set; }
    }
}
