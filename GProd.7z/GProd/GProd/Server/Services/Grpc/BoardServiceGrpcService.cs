﻿using Google.Protobuf.WellKnownTypes;
using GProd.Business.Commons;
using GProd.Shared;
using GProd.Shared.Dtos.Boards;
using Grpc.Core;
using Microsoft.AspNetCore.Cors.Infrastructure;
using static GProd.Shared.ActionService;
using Action = GProd.Shared.Action;

namespace GProd.Server.Services.Grpc
{
    public class BoardServiceGrpcService : ActionServiceBase
    {
        private readonly DataContext _dataContext;

        public BoardServiceGrpcService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public override Task<ActionReply> GetActions(Empty request, ServerCallContext context)
        {
            ActionReply reply = new ();

            reply.Actions.AddRange(_dataContext.KanbanTasks
                .Select(o => new Action()
                {
                    Id = o.Id.ToString(),
                    Title = o.Label,
                    Status = o.Status,
                    Summary = o.Description
                }));

            return Task.FromResult(reply);
        }
    }
}
