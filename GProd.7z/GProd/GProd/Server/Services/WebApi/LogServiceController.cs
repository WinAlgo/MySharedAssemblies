using GProd.Business.Commons;
using GProd.Business.Diagrams.Kanbans;
using GProd.Shared;
using GProd.Shared.Dtos;
using GProd.Shared.Dtos.Boards;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace GProd.Server.Services.WebApi
{
    public class LogServiceController : ServiceBase
    {
        public LogServiceController(ILogger<LogServiceController> logger, DataContext dataContext)
            : base(logger, dataContext)
        {

        }

        [HttpPost]
        public IActionResult Add([FromBody] LogDto logDto)
        {
            _logger.LogInformation(logDto.Message);

            return Ok();
        }
    }
}
