using GProd.Business.Commons;
using GProd.Business.Diagrams.Kanbans;
using GProd.Shared;
using GProd.Shared.Dtos.Boards;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata.Ecma335;

namespace GProd.Server.Services.WebApi
{
    public class BoardServiceController : ServiceBase
    {
        public BoardServiceController(ILogger<BoardServiceController> logger, DataContext dataContext)
            : base(logger, dataContext)
        {

        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await (_dataContext.KanbanTasks
                .Select(o => new BoardAction(o.Id.ToString(), o.Label, o.Status, o.Description)))
                .ToArrayAsync();

            return Ok(data);
        }
    }
}
