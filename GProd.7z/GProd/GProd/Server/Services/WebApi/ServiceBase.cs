﻿using GProd.Business.Commons;
using Microsoft.AspNetCore.Mvc;

namespace GProd.Server.Services.WebApi
{

    [ApiController]
    [Route("[controller]")]
    public class ServiceBase : ControllerBase
    {
        protected readonly ILogger _logger;
        protected readonly DataContext _dataContext;

        public ServiceBase(ILogger logger, DataContext dataContext)
        {
            _logger = logger;
            _dataContext = dataContext;
        }
    }
}
