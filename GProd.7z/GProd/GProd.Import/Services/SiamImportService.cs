﻿using GProd.Business.Commons;
using GProd.Import.Imports;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Import.Services
{
    public interface ISiamImportService
    {
        Task ImportFile(string pathToFile);
    }

    public class SiamImportService : ISiamImportService
    {
        private readonly ILogger<SiamImportService> _logger;
        private readonly DataContext _dataContext;

        public SiamImportService(ILogger<SiamImportService> logger, DataContext dataContext)
        {
            _logger = logger;
            _dataContext = dataContext;
        }

        public async Task ImportFile(string pathToFile)
        {
            if (!File.Exists(pathToFile))
                return;

            ImportTask importTask = new();

            _logger.LogInformation($"Starting import '{pathToFile}'");

            var tasksImported = importTask.Import(_dataContext, pathToFile);

            _logger.LogInformation($"Completed import of {pathToFile} : {tasksImported.Count()} task(s) imported");
        }
    }
}
