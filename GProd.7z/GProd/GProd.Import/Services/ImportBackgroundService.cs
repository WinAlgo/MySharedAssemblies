﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GProd.Import.Services
{
    public class ImportBackgroundService : BackgroundService
    {
        private readonly ISiamImportService _appService;
        private readonly ILogger<ImportBackgroundService> _logger;

        private string _directoryName = Path.Join (Environment.CurrentDirectory, "files");
        private string _fileFilter = "*.*";
        FileSystemWatcher _fileSystemWatcher;
        IServiceProvider _serviceProvider;

        public ImportBackgroundService(ISiamImportService appService, ILogger<ImportBackgroundService> logger,
                             IServiceProvider serviceProvider)
        {
            if (!Directory.Exists(_directoryName))
                Directory.CreateDirectory(_directoryName);
            _fileSystemWatcher = new FileSystemWatcher(_directoryName, _fileFilter);
            _serviceProvider = serviceProvider;
            _logger = logger;
            ConfigureFileSystemWatcher();
        }

        private void ConfigureFileSystemWatcher()
        {
            _fileSystemWatcher.NotifyFilter = NotifyFilters.Attributes
                                 | NotifyFilters.CreationTime
                                 | NotifyFilters.DirectoryName
                                 | NotifyFilters.FileName
                                 | NotifyFilters.LastAccess
                                 | NotifyFilters.LastWrite
                                 | NotifyFilters.Security
                                 | NotifyFilters.Size;

            _fileSystemWatcher.Changed += (sender, e) => { };
            _fileSystemWatcher.Created += (sender, e) => {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var consumerService = scope.ServiceProvider.GetRequiredService<ISiamImportService>();
                    Task.Run(() => consumerService.ImportFile(e.FullPath));

                    _logger.LogInformation($"File Watching has started for directory {_directoryName}");
                }
            };
            _fileSystemWatcher.Deleted += (sender, e) => {
                _logger.LogInformation($"File deleted event for file {e.FullPath}");
            };
            _fileSystemWatcher.Renamed += (sender, e) =>
            {
                _logger.LogInformation($"File rename event for file {e.FullPath}");
            };
            _fileSystemWatcher.Error += (sender, e) =>
            {
                _logger.LogInformation($"File error event {e.GetException().Message}");
            };

            _fileSystemWatcher.EnableRaisingEvents = true;
            _fileSystemWatcher.IncludeSubdirectories = true;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }
}
