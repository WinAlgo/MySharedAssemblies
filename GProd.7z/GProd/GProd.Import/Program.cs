﻿using GProd.Business.Commons;
using GProd.Import.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Import Data Service Starting ...");

IHostBuilder hostBuilder = Host.CreateDefaultBuilder(args);

using IHost host = hostBuilder
    .UseWindowsService(options =>
    {
        options.ServiceName = "Siam Import Service";
    })
    .ConfigureServices((hostContext, services) =>
    {
        services.AddSingleton<ISiamImportService, SiamImportService>();
        services.AddHostedService<ImportBackgroundService>();

        services.AddDbContext<DataContext>(options =>
                options.UseNpgsql(hostContext.Configuration.GetConnectionString("DefaultConnection")));
    })
    .Build();

var services = host.Services;

await host.RunAsync();