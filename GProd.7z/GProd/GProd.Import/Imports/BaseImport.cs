﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GProd.Import.Imports
{
    public class BaseImport
    {
        protected readonly JsonSerializerOptions _options = new()
        {
            PropertyNameCaseInsensitive = true
        };
    }
}
