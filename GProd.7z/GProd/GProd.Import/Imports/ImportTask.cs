﻿using GProd.Business.Commons;
using GProd.Business.Diagrams.Kanbans;
using GProd.Import.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GProd.Import.Imports
{
    public class ImportTask : BaseImport
    {
        public List<ModelTask> GetInstances(string pathFile)
        {
            using StreamReader streamReader = new(pathFile);
            var json = streamReader.ReadToEnd();
            List<ModelTask> data = JsonSerializer.Deserialize<List<ModelTask>>(json, _options);
            return data;
        }

        public IEnumerable<KanbanTask> Import(DataContext dataContext, string pathFile)
        {
            var dataInput = GetInstances(pathFile);
            var itemInput = dataInput.Select(o => new KanbanTask(o.Label, o.Status, o.Description));
            List<KanbanTask> itemOutput = new();

            foreach (KanbanTask item in itemInput)
            {
                if (!dataContext.KanbanTasks.Any(o => o.Label == item.Label))
                {
                    dataContext.Add(item);
                    itemOutput.Add(item);
                }
            }

            dataContext.SaveChanges();

            return itemOutput;
        }
    }
}
