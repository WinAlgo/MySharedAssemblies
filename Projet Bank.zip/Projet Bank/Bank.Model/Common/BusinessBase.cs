﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Common
{
    public class BusinessBase : IBusinessBase
    {

        #region Attributs et accesseurs
        public Guid Id { get; private init; }
        #endregion

        #region Constructeurs et finaliseur
        public BusinessBase(Guid id)
        {
            this.Id = id;
        }

        public BusinessBase()
            : this(Guid.NewGuid())
        {

        }
        #endregion

        n Méthodes
#regio
        #endregion

    }
}
