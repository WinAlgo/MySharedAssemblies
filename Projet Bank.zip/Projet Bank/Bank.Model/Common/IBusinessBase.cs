﻿namespace Bank.Model.Common
{
    public interface IBusinessBase
    {
        Guid Id { get; }
    }
}