﻿using Bank.Model.Clients;
using Bank.Model.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Banks
{
    public class Bank : BusinessBase, IBank
    {

        #region Attributs et accesseurs
        public string Name { get; private init; }

        public List<Client> Clients { get; private init; }

        private static Bank _Instance;
        public static Bank Instance
        {
            get
            {
                if (Bank._Instance == null)
                    Bank._Instance = new Bank("General Society");

                return Bank._Instance;
            }
            set { Bank._Instance = value; }
        }
        #endregion

        #region Constructeurs et finaliseur
        private Bank(string name)
            : base()
        {
            // Initialisation des attributs.
            this.Name = name;
            this.Clients = new List<Client>();
        }
        #endregion

        #region Méthodes

        #endregion

    }
}
