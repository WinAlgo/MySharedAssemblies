﻿using Bank.Model.Clients;
using Bank.Model.Common;

namespace Bank.Model.Banks
{
    public interface IBank : IBusinessBase
    {
        List<Client> Clients { get; }
        string Name { get; }
    }
}