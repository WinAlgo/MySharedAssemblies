﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Clients
{
    public class Person : Client
    {

        #region Attributs et accesseurs
        public string Lastname { get; private init; }

        public string Firstname { get; private init; }

        public override string Information
        {
            get { return $"{this.Lastname} {this.Firstname}"; }
        }
        #endregion

        #region Constructeurs et finaliseur
        public Person(string lastname, string firstname)
            : base()
        {
            this.Lastname = lastname;
            this.Firstname = firstname;
        }
        #endregion

        #region Méthodes
        public override void EditerListeComptes()
        {
            
        }
        #endregion

    }
}
