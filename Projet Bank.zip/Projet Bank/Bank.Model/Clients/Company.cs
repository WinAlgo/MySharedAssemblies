﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Clients
{
    public class Company : Client
    {

        #region Attributs et accesseurs
        public string Name { get; private init; }

        public override string Information
        {
            get { return Name; }
        }
        #endregion

        #region Constructeurs et finaliseur
        public Company(string name)
            : base()
        {
            this.Name = name;
        }
        #endregion

        #region Méthodes
        public override void EditerListeComptes()
        {

        }
        #endregion

    }
}
