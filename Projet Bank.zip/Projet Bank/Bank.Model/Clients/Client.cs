﻿using Bank.Model.Accounts;
using Bank.Model.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Clients
{
    public abstract class Client : BusinessBase
    {

        #region Attributs et accesseurs
        public List<Account> Accounts { get; private init; }

        public abstract string Information { get; }
        #endregion

        #region Constructeurs et finaliseur
        protected Client()
        {
            this.Accounts = new List<Account>();
        }
        #endregion

        #region Méthodes
        public abstract void EditerListeComptes();

        public override string ToString()
        {
            return this.Information;
        }
        #endregion

    }
}
