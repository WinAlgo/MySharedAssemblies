﻿using Bank.Model.Common;
using Bank.Model.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Accounts
{
    public class Account : BusinessBase
    {

        #region Attributs et accesseurs
        public string Label { get; private init; }

        public List<Operation> Operations { get; private init; }

        public double OverdraftAmount { get; private init; }
        #endregion

        #region Constructeurs et finaliseur
        public Account(string label, double overdraftAmount)
        {
            this.Label = label;
            this.OverdraftAmount = overdraftAmount;
            this.Operations = new List<Operation>();
        }

        public Account(string aLibelle)
            : this(aLibelle, 1000)
        {

        }
        #endregion

        #region Méthodes
        public double GetBalance()
        {
            return this.Operations.Select(o => o.Amount).Sum();
        }
        #endregion

    }
}
