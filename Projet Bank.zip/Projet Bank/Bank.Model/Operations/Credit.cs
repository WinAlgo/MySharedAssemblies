﻿using Bank.Model.Clients;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Operations
{
    public class Credit : Operation
    {

        #region Attributs et accesseurs
        public bool IsWire { get; private init; }
        public Client Sender { get; private init; }
        #endregion

        #region Constructeurs et finaliseur
        public Credit(Client sender, string label, double amount, bool isWire)
            : base(label, amount)
        {
            this.IsWire = isWire;
            this.Sender = sender;
        }
        #endregion

        #region Méthodes

        #endregion

    }
}
