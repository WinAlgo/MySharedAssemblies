﻿using Bank.Model.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Operations
{
    public abstract class Operation : BusinessBase
    {

        #region Attributs et accesseurs
        /// <summary>
        /// Accesseur par défaut
        /// </summary>
        public string Label { get; private init; }

        /// <summary>
        /// Accesseur standard
        /// </summary>
        private DateTime _Date;
        public DateTime Date
        {
            get { return _Date; }
            set { _Date = value; }
        }

        /// <summary>
        /// Accesseur basé sur des expressions lambda
        /// </summary>
        private double _Amount;
        public virtual double Amount { get => _Amount; set => _Amount = value; }
        #endregion

        #region Constructeurs et finaliseur
        public Operation(string label, double amount)
            : base()
        {
            this.Label = label;
            this.Amount = amount;
            this.Date = DateTime.Now;
        }
        #endregion

        #region Méthodes

        #endregion

    }
}
