﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bank.Model.Operations
{
    public class Debit : Operation
    {

        #region Attributs et accesseurs
        public override double Amount
        {
            get
            {
                return base.Amount * -1;
            }
            set
            {
                base.Amount = Math.Abs(value);
            }
        }
        #endregion

        #region Constructeurs et finaliseur
        public Debit(string label, double amount)
            : base(label, amount)
        {

        }
        #endregion

        #region Méthodes

        #endregion

    }
}
