﻿using Microsoft.AspNetCore.Mvc;

namespace Bank.Services.Controllers.Common
{
    public class AppController : ControllerBase
    {

        protected async Task<string> GetBodyContent()
        {
            using var stream = new StreamReader(this.Request.Body);
            return await stream.ReadToEndAsync();
        }

    }
}
