using Bank.Dto;
using Bank.Model.Banks;
using Bank.Model.Clients;
using Bank.Services.Controllers.Common;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Bank.Services.Controllers.Services
{
    [ApiController]
    [Route("api/[controller]")]
    public class BankController : AppController
    {
        private readonly IBank _bank;

        public BankController(IBank bank)
        {
            this._bank = bank;
        }

        [HttpGet("Information")]
        public IActionResult Information()
        {
            return this.Ok(new { this._bank.Id, this._bank.Name, this._bank.Clients.Count });
        }

        [HttpPost("AddClient")]
        //public IActionResult AddClient([FromQuery]string lastname, [FromQuery] string firstname)
        public async Task<IActionResult> AddClient()
        {
            string json = await this.GetBodyContent();

            ClientInputDto data = JsonSerializer.Deserialize<ClientInputDto>(json);

            var person = new Person(data.lastname, data.firstname);
            this._bank.Clients.Add(person);

            return this.Ok(person.Id.ToString());
        }
    }
}