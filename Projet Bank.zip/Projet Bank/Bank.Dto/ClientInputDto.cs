﻿namespace Bank.Dto
{
    public record ClientInputDto(string lastname, string firstname);
}