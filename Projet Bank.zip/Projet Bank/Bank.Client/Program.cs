﻿using System.Text.Json;

namespace Bank.Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankTest bankTest;

            try
            {
                bankTest = new BankTest();

                Guid uidClient = bankTest.CreateClient("Doe", "John").GetAwaiter().GetResult();
                Console.WriteLine($"Id Client: {uidClient}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}