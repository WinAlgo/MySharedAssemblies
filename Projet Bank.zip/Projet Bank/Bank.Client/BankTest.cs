﻿using Bank.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Bank.Client
{
    internal class BankTest
    {
        private readonly string _urlBase;

        public BankTest()
        {
            this._urlBase = "http://localhost:5120/";
        }

        public async Task<Guid> CreateClient(string lastname, string firstname)
        {
            HttpClient client = new HttpClient();
            Guid uidClient;

            HttpResponseMessage result = await client.PostAsync($"{this._urlBase}api/bank/AddClient",
                                                                new StringContent(JsonSerializer.Serialize(new ClientInputDto(lastname, firstname))));

            //HttpResponseMessage result = await client.PostAsync($"{this._urlBase}api/bank/AddClient?lastname={lastname}&firstname={firstname}", null);

            result.EnsureSuccessStatusCode();

            string s = await result.Content.ReadAsStringAsync();

            uidClient = Guid.Parse(s);

            return uidClient;
        }
    }
}
