﻿using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis.Text;

namespace Sgme.Common.Generators
{
    [Generator]
    public class IamPermissionGenerator : ISourceGenerator
    {
        //private static readonly DiagnosticDescriptor InvalidXmlWarning = new DiagnosticDescriptor(id: "SG000001",
        //                                                                                      title: "Error",
        //                                                                                      messageFormat: "Error : '{0}'",
        //                                                                                      category: "MyXmlGenerator",
        //                                                                                      DiagnosticSeverity.Error,
        //                                                                                      isEnabledByDefault: true);
        public void Initialize(GeneratorInitializationContext context)
        {
        }

        public void Execute(GeneratorExecutionContext context)
        {
            //#if DEBUG
            //        System.Diagnostics.Debugger.Launch();
            //#endif

            //try
            //{
                var csharp = "public class Hello" +
                    " {" +
                    "public int i {get; set;}" +
                    "}";

                context.AddSource("IamPermission.g.cs",
                    SourceText.From(csharp, Encoding.UTF8));
            //}
            //catch(Exception ex)
            //{
            //    context.ReportDiagnostic(Diagnostic.Create(InvalidXmlWarning, Location.None, ex.Message)) ;
            //}
        }
    }
}